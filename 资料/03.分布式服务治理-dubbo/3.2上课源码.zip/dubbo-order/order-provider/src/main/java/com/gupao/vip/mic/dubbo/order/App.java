package com.gupao.vip.mic.dubbo.order;

import com.alibaba.dubbo.container.Main;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args ) {
        Main.main(args);
    }
}
